```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26200.7840)
13th Gen Intel Core i9-13900K, 1 CPU, 32 logical and 24 physical cores
.NET SDK 10.0.101
  [Host]   : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2
  ShortRun : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

```
| Method                               | Categories  | N        | Mean            | Error            | StdDev         | Ratio | RatioSD | Rank | Allocated | Alloc Ratio |
|------------------------------------- |------------ |--------- |----------------:|-----------------:|---------------:|------:|--------:|-----:|----------:|------------:|
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 1000     |        43.95 ns |        21.438 ns |       1.175 ns |  0.15 |    0.01 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 1000     |        47.78 ns |         8.538 ns |       0.468 ns |  0.16 |    0.00 |    1 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 1000     |       289.19 ns |       147.962 ns |       8.110 ns |  0.99 |    0.04 |    2 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 1000     |       291.93 ns |       164.822 ns |       9.034 ns |  1.00 |    0.04 |    2 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 1000     |       298.77 ns |        63.312 ns |       3.470 ns |  1.02 |    0.03 |    2 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 1000     |       363.03 ns |       281.979 ns |      15.456 ns |  1.24 |    0.06 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 100000   |     6,322.54 ns |       405.722 ns |      22.239 ns |  0.23 |    0.00 |    1 |         - |          NA |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 100000   |     6,873.20 ns |     1,786.699 ns |      97.935 ns |  0.24 |    0.00 |    1 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 100000   |    28,058.82 ns |     3,617.682 ns |     198.297 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 100000   |    28,238.08 ns |     4,551.824 ns |     249.501 ns |  1.01 |    0.01 |    2 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 100000   |    28,311.92 ns |     3,256.365 ns |     178.492 ns |  1.01 |    0.01 |    2 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 100000   |    31,170.60 ns |    43,161.307 ns |   2,365.817 ns |  1.11 |    0.07 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 10000000 | 4,270,679.95 ns | 2,306,520.422 ns | 126,428.168 ns |  0.82 |    0.04 |    1 |         - |          NA |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 10000000 | 4,561,084.38 ns | 4,342,343.145 ns | 238,018.481 ns |  0.88 |    0.05 |    1 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 10000000 | 4,971,051.43 ns | 1,644,176.097 ns |  90,122.840 ns |  0.96 |    0.04 |    1 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 10000000 | 5,094,845.31 ns | 1,004,499.952 ns |  55,060.032 ns |  0.98 |    0.04 |    1 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 10000000 | 5,184,624.22 ns | 4,400,307.854 ns | 241,195.723 ns |  1.00 |    0.06 |    1 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 10000000 | 5,376,768.23 ns | 2,236,316.590 ns | 122,580.059 ns |  1.04 |    0.05 |    1 |         - |          NA |
