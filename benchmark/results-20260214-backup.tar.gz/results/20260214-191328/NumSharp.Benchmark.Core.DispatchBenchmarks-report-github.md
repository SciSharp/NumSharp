```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26200.7840)
13th Gen Intel Core i9-13900K, 1 CPU, 32 logical and 24 physical cores
.NET SDK 10.0.101
  [Host]   : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2
  ShortRun : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

```
| Method                               | Categories  | N        | Mean            | Error            | StdDev         | Ratio | RatioSD | Rank | Allocated | Alloc Ratio |
|------------------------------------- |------------ |--------- |----------------:|-----------------:|---------------:|------:|--------:|-----:|----------:|------------:|
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 1000     |        42.81 ns |         4.147 ns |       0.227 ns |  0.15 |    0.00 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 1000     |        45.77 ns |         6.577 ns |       0.361 ns |  0.16 |    0.00 |    1 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 1000     |       274.81 ns |        31.915 ns |       1.749 ns |  0.98 |    0.01 |    2 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 1000     |       279.31 ns |        43.491 ns |       2.384 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 1000     |       279.42 ns |        74.670 ns |       4.093 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 1000     |       287.28 ns |        77.681 ns |       4.258 ns |  1.03 |    0.02 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 100000   |     6,401.92 ns |     1,405.610 ns |      77.046 ns |  0.23 |    0.00 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 100000   |     6,626.35 ns |       253.335 ns |      13.886 ns |  0.24 |    0.00 |    1 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 100000   |    28,118.89 ns |     1,911.356 ns |     104.768 ns |  1.00 |    0.00 |    2 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 100000   |    28,134.29 ns |    17,356.415 ns |     951.364 ns |  1.00 |    0.03 |    2 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 100000   |    28,240.54 ns |     7,330.719 ns |     401.821 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 100000   |    28,728.09 ns |    12,275.579 ns |     672.866 ns |  1.02 |    0.02 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 10000000 | 4,027,491.41 ns | 1,140,043.902 ns |  62,489.653 ns |  0.83 |    0.05 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 10000000 | 4,283,873.05 ns | 3,745,692.590 ns | 205,314.051 ns |  0.88 |    0.06 |    1 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 10000000 | 4,767,937.76 ns |   469,958.681 ns |  25,760.021 ns |  0.98 |    0.05 |    1 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 10000000 | 4,829,712.50 ns | 1,592,677.816 ns |  87,300.046 ns |  0.99 |    0.06 |    1 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 10000000 | 4,866,898.96 ns | 2,412,215.432 ns | 132,221.668 ns |  1.00 |    0.06 |    1 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 10000000 | 4,883,878.91 ns | 5,899,900.012 ns | 323,393.429 ns |  1.00 |    0.08 |    1 |         - |          NA |
