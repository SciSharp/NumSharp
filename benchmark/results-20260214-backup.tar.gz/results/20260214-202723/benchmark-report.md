# NumSharp vs NumPy Performance

**Baseline:** NumPy (N=10M elements)

**Ratio** = NumSharp ÷ NumPy → Lower is better for NumSharp

| | Status | Ratio | Meaning |
|:-:|--------|:-----:|---------|
|✅| Faster | <1.0 | NumSharp beats NumPy |
|🟡| Close | 1-2x | Acceptable parity |
|🟠| Slower | 2-5x | Optimization target |
|🔴| Slow | >5x | Priority fix |
|⚪| Pending | - | C# benchmark not run |

---

**Summary:** 10 ops | ✅ 0 | 🟡 0 | 🟠 0 | 🔴 0 | ⚪ 10

### Reduction

| | Operation | Type | NumPy | NumSharp | Ratio |
|:-:|-----------|:----:|------:|---------:|------:|
|⚪| np.sum (float64) | float64 | 5.0 | - | - |
|⚪| np.sum axis=0 (float64) | float64 | 3.6 | - | - |
|⚪| np.sum axis=1 (float64) | float64 | 5.3 | - | - |
|⚪| np.mean (float64) | float64 | 5.4 | - | - |
|⚪| np.var (float64) | float64 | 30.9 | - | - |
|⚪| np.std (float64) | float64 | 31.2 | - | - |
|⚪| np.amin (float64) | float64 | 3.6 | - | - |
|⚪| np.amax (float64) | float64 | 4.3 | - | - |
|⚪| np.argmin (float64) | float64 | 4.4 | - | - |
|⚪| np.argmax (float64) | float64 | 4.3 | - | - |
