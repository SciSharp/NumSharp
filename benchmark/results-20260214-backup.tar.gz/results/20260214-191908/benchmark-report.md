# NumSharp vs NumPy Performance

**Baseline:** NumPy (N=10M elements)

**Ratio** = NumSharp ÷ NumPy → Lower is better for NumSharp

| | Status | Ratio | Meaning |
|:-:|--------|:-----:|---------|
|✅| Faster | <1.0 | NumSharp beats NumPy |
|🟡| Close | 1-2x | Acceptable parity |
|🟠| Slower | 2-5x | Optimization target |
|🔴| Slow | >5x | Priority fix |
|⚪| Pending | - | C# benchmark not run |

---

**Summary:** 5 ops | ✅ 0 | 🟡 0 | 🟠 0 | 🔴 0 | ⚪ 5

### Arithmetic

| | Operation | Type | NumPy | NumSharp | Ratio |
|:-:|-----------|:----:|------:|---------:|------:|
|⚪| a + b (int32) | int32 | 9.0 | - | - |
|⚪| a + scalar (int32) | int32 | 8.1 | - | - |
|⚪| a - b (int32) | int32 | 9.0 | - | - |
|⚪| a * b (int32) | int32 | 9.0 | - | - |
|⚪| a * a (int32) | int32 | 8.4 | - | - |
