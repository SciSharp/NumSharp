```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26200.7840)
13th Gen Intel Core i9-13900K, 1 CPU, 32 logical and 24 physical cores
.NET SDK 10.0.101
  [Host]   : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2
  ShortRun : .NET 10.0.1 (10.0.125.57005), X64 RyuJIT AVX2

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

```
| Method                               | Categories  | N        | Mean            | Error            | StdDev         | Ratio | RatioSD | Rank | Allocated | Alloc Ratio |
|------------------------------------- |------------ |--------- |----------------:|-----------------:|---------------:|------:|--------:|-----:|----------:|------------:|
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 1000     |        44.80 ns |         1.542 ns |       0.085 ns |  0.15 |    0.00 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 1000     |        48.32 ns |         3.774 ns |       0.207 ns |  0.17 |    0.00 |    1 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 1000     |       286.61 ns |        20.289 ns |       1.112 ns |  0.99 |    0.01 |    2 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 1000     |       289.55 ns |        29.747 ns |       1.631 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 1000     |       290.49 ns |        52.594 ns |       2.883 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 1000     |       292.99 ns |        24.713 ns |       1.355 ns |  1.01 |    0.01 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 100000   |     6,444.00 ns |       769.842 ns |      42.198 ns |  0.22 |    0.00 |    1 |         - |          NA |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 100000   |     6,598.57 ns |     1,535.845 ns |      84.185 ns |  0.23 |    0.00 |    1 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 100000   |    28,248.08 ns |     2,793.463 ns |     153.119 ns |  0.98 |    0.01 |    2 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 100000   |    28,609.59 ns |     2,969.297 ns |     162.757 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 100000   |    28,739.77 ns |     5,100.115 ns |     279.555 ns |  1.00 |    0.01 |    2 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 100000   |    29,300.10 ns |     4,022.618 ns |     220.493 ns |  1.02 |    0.01 |    2 |         - |          NA |
|                                      |             |          |                 |                  |                |       |         |      |           |             |
| &#39;Hand-written SIMD (Vector256)&#39;      | Reference   | 10000000 | 4,134,065.89 ns | 2,316,320.445 ns | 126,965.340 ns |  0.80 |    0.02 |    1 |         - |          NA |
| &#39;DynamicMethod SIMD (Vector256)&#39;     | Proposed    | 10000000 | 4,199,535.94 ns |   774,217.808 ns |  42,437.491 ns |  0.81 |    0.01 |    1 |         - |          NA |
| &#39;Static Op.Add() [NumSharp current]&#39; | Current     | 10000000 | 5,192,857.03 ns | 1,608,325.724 ns |  88,157.760 ns |  1.00 |    0.02 |    1 |         - |          NA |
| &#39;DynamicMethod scalar ptr&#39;           | Proposed    | 10000000 | 5,233,279.43 ns | 2,580,935.048 ns | 141,469.760 ns |  1.01 |    0.03 |    1 |         - |          NA |
| &#39;Struct&lt;AddOp&gt; via IBinOp&lt;T&gt;&#39;        | Alternative | 10000000 | 5,352,064.84 ns | 2,373,028.291 ns | 130,073.689 ns |  1.03 |    0.03 |    1 |         - |          NA |
| &#39;Raw ptr loop (inline a+b)&#39;          | Baseline    | 10000000 | 5,396,696.61 ns | 1,341,207.425 ns |  73,516.105 ns |  1.04 |    0.02 |    1 |         - |          NA |
