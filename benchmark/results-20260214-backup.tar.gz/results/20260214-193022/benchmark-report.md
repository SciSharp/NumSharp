# NumSharp vs NumPy Performance

**Baseline:** NumPy (N=10M elements)

**Ratio** = NumSharp ÷ NumPy → Lower is better for NumSharp

| | Status | Ratio | Meaning |
|:-:|--------|:-----:|---------|
|✅| Faster | <1.0 | NumSharp beats NumPy |
|🟡| Close | 1-2x | Acceptable parity |
|🟠| Slower | 2-5x | Optimization target |
|🔴| Slow | >5x | Priority fix |
|⚪| Pending | - | C# benchmark not run |

---

**Summary:** 3 ops | ✅ 0 | 🟡 0 | 🟠 0 | 🔴 0 | ⚪ 3

### Dispatch

| | Operation | Type | NumPy | NumSharp | Ratio |
|:-:|-----------|:----:|------:|---------:|------:|
|⚪| np.add(a, b, out=c) | int32 | 6.7 | - | - |
|⚪| c = a + b (allocates) | int32 | 17.2 | - | - |
|⚪| np.add(a, scalar, out=c) | int32 | 4.9 | - | - |
